/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionewwewe;
    QAction *actioncuotiben;
    QAction *actionlishijiu;
    QAction *actionshuchuchengji;
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QStackedWidget *stackedWidget1;
    QWidget *page_3;
    QLabel *label_4;
    QLabel *label_5;
    QTextBrowser *textBrowser_2;
    QLabel *label_6;
    QTextBrowser *textBrowser_3;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QWidget *page;
    QPushButton *pushButton;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLabel *label_7;
    QLabel *label_8;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QRadioButton *radioButton_3;
    QLabel *label_12;
    QPushButton *pushButton_6;
    QLabel *label;
    QWidget *page_2;
    QTextBrowser *textBrowser;
    QTextEdit *textEdit;
    QPushButton *pushButton_2;
    QLabel *label_2;
    QLabel *label_3;
    QLCDNumber *lcdNumber;
    QLabel *label_10;
    QLabel *label_11;
    QMenuBar *menuBar;
    QMenu *menu;
    QMenu *menu_2;
    QStatusBar *statusBar;
    QToolBar *mainToolBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(581, 440);
        MainWindow->setMinimumSize(QSize(581, 440));
        MainWindow->setMaximumSize(QSize(581, 440));
        MainWindow->setStyleSheet(QStringLiteral(""));
        actionewwewe = new QAction(MainWindow);
        actionewwewe->setObjectName(QStringLiteral("actionewwewe"));
        QIcon icon;
        icon.addFile(QStringLiteral(":/ooopic_1523791413.ico"), QSize(), QIcon::Normal, QIcon::Off);
        actionewwewe->setIcon(icon);
        actioncuotiben = new QAction(MainWindow);
        actioncuotiben->setObjectName(QStringLiteral("actioncuotiben"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/ooopic_1523791490.ico"), QSize(), QIcon::Normal, QIcon::Off);
        actioncuotiben->setIcon(icon1);
        actionlishijiu = new QAction(MainWindow);
        actionlishijiu->setObjectName(QStringLiteral("actionlishijiu"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/ooopic_1523791477.ico"), QSize(), QIcon::Normal, QIcon::Off);
        actionlishijiu->setIcon(icon2);
        actionshuchuchengji = new QAction(MainWindow);
        actionshuchuchengji->setObjectName(QStringLiteral("actionshuchuchengji"));
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/ooopic_1523791528.ico"), QSize(), QIcon::Normal, QIcon::Off);
        actionshuchuchengji->setIcon(icon3);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        stackedWidget1 = new QStackedWidget(centralWidget);
        stackedWidget1->setObjectName(QStringLiteral("stackedWidget1"));
        stackedWidget1->setStyleSheet(QStringLiteral(""));
        page_3 = new QWidget();
        page_3->setObjectName(QStringLiteral("page_3"));
        label_4 = new QLabel(page_3);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(130, 8, 308, 71));
        label_5 = new QLabel(page_3);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(11, 191, 135, 16));
        textBrowser_2 = new QTextBrowser(page_3);
        textBrowser_2->setObjectName(QStringLiteral("textBrowser_2"));
        textBrowser_2->setGeometry(QRect(160, 180, 101, 41));
        label_6 = new QLabel(page_3);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(70, 130, 75, 16));
        textBrowser_3 = new QTextBrowser(page_3);
        textBrowser_3->setObjectName(QStringLiteral("textBrowser_3"));
        textBrowser_3->setGeometry(QRect(160, 120, 101, 41));
        pushButton_3 = new QPushButton(page_3);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(370, 90, 121, 61));
        pushButton_4 = new QPushButton(page_3);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(370, 170, 121, 61));
        pushButton_5 = new QPushButton(page_3);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(370, 250, 121, 61));
        stackedWidget1->addWidget(page_3);
        page = new QWidget();
        page->setObjectName(QStringLiteral("page"));
        pushButton = new QPushButton(page);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(330, 140, 161, 101));
        pushButton->setStyleSheet(QString::fromUtf8("font: 14pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";"));
        lineEdit = new QLineEdit(page);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(160, 160, 91, 31));
        lineEdit_2 = new QLineEdit(page);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(160, 210, 91, 31));
        label_7 = new QLabel(page);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(70, 170, 72, 15));
        label_8 = new QLabel(page);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(40, 220, 101, 20));
        radioButton = new QRadioButton(page);
        radioButton->setObjectName(QStringLiteral("radioButton"));
        radioButton->setGeometry(QRect(140, 260, 115, 19));
        radioButton->setStyleSheet(QStringLiteral(""));
        radioButton_2 = new QRadioButton(page);
        radioButton_2->setObjectName(QStringLiteral("radioButton_2"));
        radioButton_2->setGeometry(QRect(200, 260, 115, 19));
        radioButton_3 = new QRadioButton(page);
        radioButton_3->setObjectName(QStringLiteral("radioButton_3"));
        radioButton_3->setGeometry(QRect(290, 260, 115, 19));
        label_12 = new QLabel(page);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(40, 260, 101, 21));
        pushButton_6 = new QPushButton(page);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(420, 260, 93, 28));
        label = new QLabel(page);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(100, 20, 351, 121));
        label->setStyleSheet(QStringLiteral(""));
        stackedWidget1->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QStringLiteral("page_2"));
        textBrowser = new QTextBrowser(page_2);
        textBrowser->setObjectName(QStringLiteral("textBrowser"));
        textBrowser->setGeometry(QRect(11, 35, 301, 192));
        textBrowser->setStyleSheet(QStringLiteral(""));
        textEdit = new QTextEdit(page_2);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(357, 35, 191, 121));
        pushButton_2 = new QPushButton(page_2);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(370, 210, 151, 71));
        label_2 = new QLabel(page_2);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(140, 10, 61, 20));
        label_3 = new QLabel(page_2);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(400, 10, 32, 17));
        lcdNumber = new QLCDNumber(page_2);
        lcdNumber->setObjectName(QStringLiteral("lcdNumber"));
        lcdNumber->setGeometry(QRect(80, 260, 131, 41));
        label_10 = new QLabel(page_2);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(70, 10, 72, 15));
        label_11 = new QLabel(page_2);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(160, 10, 72, 15));
        stackedWidget1->addWidget(page_2);

        gridLayout->addWidget(stackedWidget1, 0, 0, 1, 1);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 581, 26));
        menu = new QMenu(menuBar);
        menu->setObjectName(QStringLiteral("menu"));
        menu_2 = new QMenu(menuBar);
        menu_2->setObjectName(QStringLiteral("menu_2"));
        MainWindow->setMenuBar(menuBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);

        menuBar->addAction(menu->menuAction());
        menuBar->addAction(menu_2->menuAction());
        menu->addAction(actionewwewe);
        menu_2->addAction(actioncuotiben);
        menu_2->addAction(actionlishijiu);
        menu_2->addAction(actionshuchuchengji);
        mainToolBar->addAction(actionewwewe);
        mainToolBar->addSeparator();
        mainToolBar->addAction(actioncuotiben);
        mainToolBar->addSeparator();
        mainToolBar->addAction(actionlishijiu);
        mainToolBar->addSeparator();
        mainToolBar->addAction(actionshuchuchengji);

        retranslateUi(MainWindow);

        stackedWidget1->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "\344\270\200\345\210\200\344\270\244\347\231\276\351\242\230", nullptr));
        actionewwewe->setText(QApplication::translate("MainWindow", "\346\226\260\345\273\272\347\255\224\351\242\230", nullptr));
#ifndef QT_NO_TOOLTIP
        actionewwewe->setToolTip(QApplication::translate("MainWindow", "\346\226\260\345\273\272\347\255\224\351\242\230", nullptr));
#endif // QT_NO_TOOLTIP
        actioncuotiben->setText(QApplication::translate("MainWindow", "\351\224\231\351\242\230\346\234\254", nullptr));
#ifndef QT_NO_TOOLTIP
        actioncuotiben->setToolTip(QApplication::translate("MainWindow", "\351\224\231\351\242\230\346\234\254", nullptr));
#endif // QT_NO_TOOLTIP
        actionlishijiu->setText(QApplication::translate("MainWindow", "\345\216\206\345\217\262\350\256\260\345\275\225", nullptr));
#ifndef QT_NO_TOOLTIP
        actionlishijiu->setToolTip(QApplication::translate("MainWindow", "\345\216\206\345\217\262\350\256\260\345\275\225", nullptr));
#endif // QT_NO_TOOLTIP
        actionshuchuchengji->setText(QApplication::translate("MainWindow", "\347\224\237\346\210\220\346\210\220\347\273\251\345\215\225", nullptr));
#ifndef QT_NO_TOOLTIP
        actionshuchuchengji->setToolTip(QApplication::translate("MainWindow", "\347\224\237\346\210\220\346\210\220\347\273\251\345\215\225", nullptr));
#endif // QT_NO_TOOLTIP
        label_4->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:26pt; font-weight:600;\">\346\201\255\345\226\234\344\275\240\345\201\232\345\256\214\344\272\206\357\274\201</span></p></body></html>", nullptr));
        label_5->setText(QApplication::translate("MainWindow", "\344\275\240\347\232\204\345\201\232\345\257\271\347\232\204\351\242\230\347\233\256\346\225\260\357\274\232", nullptr));
        label_6->setText(QApplication::translate("MainWindow", "\346\200\273\351\242\230\347\233\256\346\225\260\357\274\232", nullptr));
        pushButton_3->setText(QApplication::translate("MainWindow", "\350\277\233\345\205\245\351\224\231\351\242\230\346\234\254", nullptr));
        pushButton_4->setText(QApplication::translate("MainWindow", "\345\206\215\346\235\245\344\270\200\346\254\241", nullptr));
        pushButton_5->setText(QApplication::translate("MainWindow", "\351\200\200\345\207\272", nullptr));
#ifndef QT_NO_TOOLTIP
        pushButton->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; font-weight:600;\">\345\274\200\345\247\213\347\255\224\351\242\230</span></p></body></html>", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_WHATSTHIS
        pushButton->setWhatsThis(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:11pt; font-weight:600;\">\345\274\200\345\247\213\347\255\224\351\242\230</span></p></body></html>", nullptr));
#endif // QT_NO_WHATSTHIS
        pushButton->setText(QApplication::translate("MainWindow", "\345\274\200\345\247\213\347\255\224\351\242\230", nullptr));
        label_7->setText(QApplication::translate("MainWindow", "\351\242\230\347\233\256\346\225\260\351\207\217\357\274\232", nullptr));
        label_8->setText(QApplication::translate("MainWindow", "\346\234\200\345\244\232\350\277\220\347\256\227\346\254\241\346\225\260\357\274\232", nullptr));
        radioButton->setText(QApplication::translate("MainWindow", "\345\212\240\345\207\217", nullptr));
        radioButton_2->setText(QApplication::translate("MainWindow", "\345\212\240\345\207\217\344\271\230\351\231\244", nullptr));
        radioButton_3->setText(QApplication::translate("MainWindow", "\345\212\240\345\207\217\344\271\230\351\231\244\344\271\230\346\226\271", nullptr));
        label_12->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\350\277\220\347\256\227\347\254\246\347\247\215\347\261\273:</p></body></html>", nullptr));
        pushButton_6->setText(QApplication::translate("MainWindow", "\351\253\230\347\272\247\351\200\211\351\241\271", nullptr));
        label->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:48pt; font-weight:600;\">\346\254\242\350\277\216\347\255\224\351\242\230</span></p></body></html>", nullptr));
        textBrowser->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'SimSun'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", nullptr));
        pushButton_2->setText(QApplication::translate("MainWindow", "\344\270\213\344\270\200\351\242\230", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><br/></p></body></html>", nullptr));
        label_3->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-weight:600;\">\347\255\224\346\241\210</span></p></body></html>", nullptr));
        label_10->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\347\254\254</p></body></html>", nullptr));
        label_11->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\351\242\230</p></body></html>", nullptr));
        menu->setTitle(QApplication::translate("MainWindow", "\346\226\207\344\273\266", nullptr));
        menu_2->setTitle(QApplication::translate("MainWindow", "\345\267\245\345\205\267", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
