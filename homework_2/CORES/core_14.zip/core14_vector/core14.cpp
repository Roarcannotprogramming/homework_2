// Core_14.cpp: ���� DLL Ӧ�ó���ĵ���������
//

//#include "stdafx.h"
#include <iostream>
#include <string>
#include <string.h>
#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include <cstdlib>
#include <ctime>
#include<vector>
#include<sstream>
#include<map>
#include<stack>
#include<sstream>

using namespace std;

bool isoptr(string ch)
{
	if (ch == "+" || ch == "-" || ch == "*" || ch == "/" || ch == "(" || ch == ")" || ch == "#")
	{
		return true;
	}
	return false;
}

int cmp(string ch1, string ch2)
{
	if (ch1 == "+" || ch1 == "-")
	{
		if (ch2 == "+" || ch2 == "-" || ch2 == ")" || ch2 == "#")
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}
	if (ch1 == "*" || ch1 == "/")
	{
		if (ch2 == "(")
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	if (ch1 == "(")
	{
		if (ch2 == ")")
		{
			return 3;
		}
		else
		{
			return 1;
		}
	}
	if (ch1 == ")")
	{
		return 0;
	}
	if (ch1 == "#")
	{
		if (ch2 == "#")
		{
			return 3;
		}
		else
		{
			return 1;
		}
	}
}

int splitfind(string str, int &i)
{
	//find split
	//int j = i;
	while (str[i] != '+' && str[i] != '-' && str[i] != '*' && str[i] != '/' && str[i] != '=')
	{
		i++;
	}
	/*
	if (j == i)
	{
	return 0;
	}
	else
	{
	return 1;
	}
	*/
	return 0;
}

int splitstr(vector<string> &vstr, string str)
{
	vstr.push_back("#");
	int i = 0, j = 0;
	string s;
	while (1)
	{
		splitfind(str, i);
		if (str[i] == '=')
		{
			break;
		}
		s = str.substr(j, i - j);//num
		vstr.push_back(s);
		s = str.substr(i, 1);//op
		vstr.push_back(s);
		i++;
		j = i;
	}
	s = str.substr(j, i - j);
	vstr.push_back(s);
	vstr.push_back("#");
	return 0;
}

int stringtodouble(string s, double &num)
{
	stringstream ss;
	ss << s;
	ss >> num;
	return 0;
}

int doubletostring(string &s, double num)
{
	stringstream ss;
	ss << num;
	s = ss.str();
	return 0;
}

int calc(vector<string> &vs, vector<string> &vscal)
{
	string str;
	vector<string> vstr;
	stack<string> OPND;
	stack<string> OPTR;
	for (int q = 0; q < vs.size(); q++)
	{
		str = vs[q];
		splitstr(vstr, str);
		OPTR.push("#");
		int i = 1;
		int k = 0;
		int sumsub = 0;
		int foundsub = 0;
		string op;
		string a, b, c;
		double doublea, doubleb, doublec;
		map<int, int> order1, order2;
		for (int j = 0; j < vstr.size(); j++)
		{
			order1[j] = j;
			order2[j] = j;
		}
		while (1)
		{
			if (!isoptr(vstr[i]))
			{
				OPND.push(vstr[i]);
				i++;
				continue;
			}
			else
			{
				while (1)
				{
					op = OPTR.top();
					switch (cmp(op, vstr[i]))
					{
					case 0:
						b = OPND.top();
						OPND.pop();
						a = OPND.top();
						OPND.pop();
						OPTR.pop();
						stringtodouble(b, doubleb);
						stringtodouble(a, doublea);
						if (op == "+")
						{
							doublec = doublea + doubleb;
							doubletostring(c, doublec);
							OPND.push(c);
						}
						if (op == "-")
						{
							sumsub++;
							doublec = doublea - doubleb;
							if (doublec < 0)
							{
								doublec = doubleb - doublea;
								for (k = 0; k < vstr.size(); k++)
								{
									if (vstr[k] == "-")
									{
										foundsub++;
									}
									if (foundsub == sumsub)
									{
										break;
									}
								}
								int k1 = k, k2 = k;
								k1--;
								k2++;
								while (vstr[k1] != "+" && vstr[k1] != "-" && vstr[k1] != "#")
								{
									k1--;
								}
								while (vstr[k2] != "+" && vstr[k2] != "-" && vstr[k2] != "#")
								{
									k2++;
								}
								int s;
								for (s = 1; s < k2 - k; s++)
								{
									order2[k1 + s] = order1[k + s];
								}
								order2[k1 + s] = k;
								int t = k1 + s;
								for (s = 1; s < k - k1; s++)
								{
									order2[t + s] = order1[k1 + s];
								}
								doubletostring(c, doublec);
								OPND.push(c);
							}
							else
							{
								doubletostring(c, doublec);
								OPND.push(c);
							}
						}
						if (op == "*")
						{
							doublec = doublea * doubleb;
							doubletostring(c, doublec);
							OPND.push(c);
						}
						if (op == "/")
						{
							doublec = doublea / doubleb;
							doubletostring(c, doublec);
							OPND.push(c);
						}
						break;
					case 1:
						OPTR.push(vstr[i]);
						break;
					case 2:
						OPTR.pop();
						break;
					default:
						break;
					}
					if (cmp(op, vstr[i]) != 0)
					{
						break;
					}
				}
			}

			if (vstr[i] == "#" && OPTR.top() == "#")
			{
				break;
			}
			i++;
		}
		string ans;
		ans = OPND.top();
		string anscal = "";
		for (int i = 1; i < vstr.size() - 1; i++)
		{
			//			cout << vstr[order2[i]];
			anscal += vstr[order2[i]];
		}
		anscal += "=";
		//		cout << "=";
		anscal += ans;
		//		cout << ans;
		vscal.push_back(anscal);
		vstr.clear();
		while (!OPND.empty())
		{
			OPND.pop();
		}
		while (!OPTR.empty())
		{
			OPTR.pop();
		}
	}
	return 0;
}

char operachar[4] = { '+','-','*','/' };
int powertable[5] = { 1,10,100,1000,10000 };


void GenerateNobrackets(vector<string> &vs, vector<string> &vscal, int numofques = 10, int numofopera = 6, int range = 10, int accuracy = 0, bool zerodiv = false)
{
	int tempques = numofques;
	int tempoper = numofopera;
	int temprang = range;
	bool tempdiv = zerodiv;
	srand((unsigned)time(NULL));
	int tempacc = accuracy;
	if ((tempacc < 0) || tempdiv)
		tempacc = 0;
	else if (tempacc > 4)
		tempacc = 4;
	int power = powertable[tempacc];
	for (int index = 0; index < tempques; index++)
	{
		bool flag = false;
		char temp[10] = { 0 };
		int actnumofoper = rand() % tempoper + 1;
		int startnumint = rand() % (temprang * power) + 1;
		double startnum = startnumint / double(power);
		switch (tempacc)
		{
		case 0:
			sprintf_s(temp, "%.0lf", startnum);
			break;
		case 1:
			sprintf_s(temp, "%.1lf", startnum);
			break;
		case 2:
			sprintf_s(temp, "%.2lf", startnum);
			break;
		case 3:
			sprintf_s(temp, "%.3lf", startnum);
			break;
		default:
			sprintf_s(temp, "%.4lf", startnum);
		}
		string temp1 = temp;
		char lastchar = '+';
		int lastnum = startnumint;
		for (int countoper = 0; countoper < actnumofoper; countoper++)
		{
			char tempoperachar = 0;
			if (('/' == lastchar) && !flag)
				tempoperachar = operachar[rand() % 3];
			else if (!flag)
				tempoperachar = operachar[rand() % 4];
			else if (('/' == lastchar) && flag)
				tempoperachar = operachar[2 * (rand() % 2)];
			else
			{
				int state = rand() % 3;
				if (1 == state)
					state = 3;
				tempoperachar = operachar[state];
			}
			if ('-' == tempoperachar)
				flag = true;
			lastchar = tempoperachar;
			int tempnumint = 0;
			if (tempdiv && '/' == tempoperachar)
			{
				if (lastnum < temprang / 2)
				{
					int newrang = temprang / lastnum;
					tempnumint = rand() % (newrang)+1;
					tempnumint *= lastnum;
				}
				else tempnumint = lastnum;
			}
			else
				tempnumint = rand() % (temprang * power) + 1;
			double tempnum = tempnumint / double(power);
			char tempright[10] = { 0 };
			switch (tempacc)
			{
			case 0:
				sprintf_s(tempright, "%.0lf", tempnum);
				break;
			case 1:
				sprintf_s(tempright, "%.1lf", tempnum);
				break;
			case 2:
				sprintf_s(tempright, "%.2lf", tempnum);
				break;
			case 3:
				sprintf_s(tempright, "%.3lf", tempnum);
				break;
			default:
				sprintf_s(tempright, "%.4lf", tempnum);
			}
			string tempright1 = tempright;
			temp1 = tempright1 + tempoperachar + temp1;
			lastnum = tempnumint;
		}
		temp1 += "=";
		vs.push_back(temp1);
		//		cout << temp1 << "=" << endl; 
	}
	calc(vs, vscal);
	int w;
	for (int i = 0; i < vscal.size(); i++)
	{
		w = vscal[i].find('=');
		vscal[i] = vscal[i].substr(w + 1);
	}
}


void Generatebrackets(vector<string> &vs, vector<string> &vscal, int numofques = 10, int numofopera = 6, int range = 10, int accuracy = 0, bool zerodiv = false)
{
	int tempques = numofques;
	int tempoper = numofopera;
	int temprang = range;
	int countques = 0;
	bool tempdiv = zerodiv;
	double result;
	if (1 == tempoper)
	{
		GenerateNobrackets(tempques, tempoper, temprang, accuracy, tempdiv, vs, vscal);
		return;
	}
	srand((unsigned)time(NULL));
	int tempacc = accuracy;
	if ((tempacc < 0) || tempdiv)
		tempacc = 0;
	else if (tempacc > 4)
		tempacc = 4;
	int power = powertable[tempacc];
	for (int index = 1; index > 0; index++)
	{
		char w[2] = { operachar[2 * (rand() % 2)] };
		string alloperator = w;
		string tempoutput = " ";
		int startnumint = rand() % (temprang * power) + 1;
		double startnum = startnumint / double(power);
		result = startnum;
		char templeft[10] = { 0 };
		switch (tempacc)
		{
		case 0:
			sprintf_s(templeft, "%.0lf", startnum);
			break;
		case 1:
			sprintf_s(templeft, "%.1lf", startnum);
			break;
		case 2:
			sprintf_s(templeft, "%.2lf", startnum);
			break;
		case 3:
			sprintf_s(templeft, "%.3lf", startnum);
			break;
		default:
			sprintf_s(templeft, "%.4lf", startnum);
		}
		string templeft1 = templeft;
		tempoutput += templeft1;
		string lastput(tempoutput, 1);
		int actnumofoper = rand() % tempoper + 1;
		for (int countoper = 1; countoper < actnumofoper; countoper++)
		{
			if ('/' == alloperator[countoper - 1])
			{
				alloperator += operachar[rand() % 3];
			}
			else
				alloperator += operachar[rand() % 4];
		}
		char tempright[10] = { 0 };
		int rightoperaint = rand() % (temprang * power) + 1;
		double rightopera = rightoperaint / double(power);
		switch (tempacc)
		{
		case 0:
			sprintf_s(tempright, "%.0lf", rightopera);
			break;
		case 1:
			sprintf_s(tempright, "%.1lf", rightopera);
			break;
		case 2:
			sprintf_s(tempright, "%.2lf", rightopera);
			break;
		case 3:
			sprintf_s(tempright, "%.3lf", rightopera);
			break;
		default:
			sprintf_s(tempright, "%.4lf", rightopera);
		}
		string tempright1 = tempright;
		int leforrig = rand() % 2;
		if (leforrig)
			lastput = tempright1 + alloperator[0] + lastput;
		else
			lastput = lastput + alloperator[0] + tempright1;
		switch (alloperator[0])
		{
		case '+':
			result += rightopera;
			break;
		default:
			result = rightopera * result;
		}
		for (int indexoper = 1; indexoper < actnumofoper; indexoper++)
		{
			rightoperaint = rand() % (temprang * power) + 1;
			rightopera = rightoperaint / double(power);
			switch (tempacc)
			{
			case 0:
				sprintf_s(tempright, "%.0lf", rightopera);
				break;
			case 1:
				sprintf_s(tempright, "%.1lf", rightopera);
				break;
			case 2:
				sprintf_s(tempright, "%.2lf", rightopera);
				break;
			case 3:
				sprintf_s(tempright, "%.3lf", rightopera);
				break;
			default:
				sprintf_s(tempright, "%.4lf", rightopera);
			}
			tempright1 = tempright;
			leforrig = rand() % 2;
			if (tempdiv && '/' == alloperator[indexoper])
			{
				if (0 == result)
					rightoperaint = rand() % (temprang)+1;
				else if (1 == result)
					rightoperaint = 1;
				else
					for (int try1 = 2; try1 <= result; try1++)
						if (0 == int(result) % try1)
						{
							rightoperaint = try1;
							break;
						}
				if (rightoperaint > temprang)
					rightoperaint = 1;
				rightopera = rightoperaint / double(power);
				sprintf_s(tempright, "%.0lf", rightopera);
				tempright1 = tempright;
				leforrig = 0;
			}
			if (leforrig && (result && ('/' == alloperator[indexoper])) && (('-' == alloperator[indexoper]) && (rightopera > result)))
			{
				if ((('+' == alloperator[indexoper - 1]) || ('-' == alloperator[indexoper - 1])) && (('*' == alloperator[indexoper]) || ('/' == alloperator[indexoper])))
				{
					lastput = tempright1 + alloperator[indexoper] + '(' + lastput + ')';
				}
				else if (('-' == alloperator[indexoper]) && (('-' == alloperator[index - 1]) || ('+' == alloperator[indexoper - 1])))
				{
					lastput = tempright1 + alloperator[indexoper] + '(' + lastput + ')';
				}
				else if (('/' == alloperator[indexoper]) && (('/' == alloperator[index - 1]) || ('*' == alloperator[indexoper - 1])))
				{
					lastput = tempright1 + alloperator[indexoper] + '(' + lastput + ')';
				}
				else
				{
					lastput = tempright1 + alloperator[indexoper] + lastput;
				}
				switch (alloperator[indexoper])
				{
				case '+':
					result += rightopera;
					break;
				case '-':
					result = rightopera - result;
					break;
				case '*':
					result *= rightopera;
					break;
				default:
					result = rightopera / result;
				}
			}
			else
			{
				if ((('+' == alloperator[indexoper - 1]) || ('-' == alloperator[indexoper - 1])) && (('*' == alloperator[indexoper]) || ('/' == alloperator[indexoper])))
				{
					lastput = '(' + lastput + ')' + alloperator[indexoper] + tempright1;
				}
				else
				{
					lastput = lastput + alloperator[indexoper] + tempright1;
				}
				switch (alloperator[indexoper])
				{
				case '+':
					result += rightopera;
					break;
				case '-':
					result -= rightopera;
					break;
				case '*':
					result *= rightopera;
					break;
				default:
					result /= rightopera;
				}
			}
		}
		if (result > 0)
		{
			vs.push_back(lastput + "=");
			stringstream ss;
			ss << result;
			vscal.push_back(lastput + "=" + ss.str());
			//			cout << lastput << '=' << result << endl;
			countques++;
		}
		if (tempques == countques)
			break;
	}
	int w;
	for (int i = 0; i < vscal.size(); i++)
	{
		w = vscal[i].find('=');
		vscal[i] = vscal[i].substr(w + 1);
	}
}




