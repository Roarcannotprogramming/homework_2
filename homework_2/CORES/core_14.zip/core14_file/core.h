#include <iostream>
#include <string>
#include <string.h>
#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include <cstdlib>
#include <ctime>
#include<vector>
#include<sstream>
#include<map>
#include<stack>
#include<sstream>

using namespace std;

void GenerateNobrackets(int numofques, int numofopera, int range, int accuracy, bool zerodiv);
void Generatebrackets(int numofques, int numofopera, int range, int accuracy, bool zerodiv);
