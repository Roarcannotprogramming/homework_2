﻿#include "question.h"
using namespace std;

int main()
{
	questionCore Work(8);

	Work.setting(40, 10, 4, 10, "+-*/^", true, 2);//num of questions, num of ops, min of nums, max of nums, ops(+-*/^), if need fraction, precise
											       // int				int			int			int          string	        bool			int
	Work.getResultFile();

	return 0;
}