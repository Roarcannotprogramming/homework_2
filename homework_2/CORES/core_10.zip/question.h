﻿#include <iostream>
#include <stdlib.h>
#include <string>
#include <vector>
#include <algorithm>
#include <stack>
#include <ctime>
#include<fstream>

#define MAXN 30000

using namespace std;

//if you are UI, just use two functions:
//setting, getResultFile
//They are defined at the end of this file
//Please read our API files
//Thanks~

class questionNode
{
public:
	int value;//num or op
	bool opsFlag;//true: op node
	questionNode* lchild;
	questionNode* rchild;
	questionNode() {
		value = 0;
		opsFlag = false;
		lchild = NULL;
		rchild = NULL;
	}

	questionNode(int val, bool flag, questionNode* lch = NULL, questionNode* rch = NULL)
	{
		value = val;
		opsFlag = flag;
		lchild = lch;
		rchild = rch;
	}
};

class questionCore
{
private:
	vector<questionNode*> questions;
	vector<char> ops = { '+','-','*','/','^' };//last two ops must be '(' ')'
	vector<string> Answer;//Answer for each question
	int maxOpNum = 4;//max num of Ops in question 
	int minRange = 2;//min num of Ops
	int range = 50;//max of each num in question,set by user
	int precise = 2;//0.01
	int quesNum;//num of questions
	int maxRange = 500000;//max of each num in question,set by coder
	bool fracFlag = true;//is fraction function
	double result[MAXN];//result
	bool fitFlag[MAXN];//set false if question[i] doesn't fit conditions
	string QuePath;
	string AnsPath;

					   //delete
	bool deleteQues(questionNode* root)
	{
		if (root->lchild != NULL)
			deleteQues(root->lchild);
		if (root->rchild != NULL)
			deleteQues(root->rchild);
		delete root;
		return true;
	}

	int random(int a, int b);//random a~b
	void questionCore::setOps();//add ( ) into ops . if fraction, add function

	bool isOp(char ch);//is operator
	bool isNum(char ch);//is num
	bool isDeci(string str);//if str contains '.'
	int priority(char op);//op's priority
	double CalcNum(double a, double b, char op);// return (a op b)
	double CalcStr(string & que);//return answer of que
	void numPush(stack<double> & stackT, string que, int & pos);//push que's nums into stackT
	int getDivisor(string instr);//find max divisor
	int gcd(int a, int b);//Euclidean algorithm, zhanzhuanxiangchufa

	bool isPositive(questionNode* root, double &res);//judge if elems in question are positive 

	bool generateTree(vector<string> & ques);//generate tree from ques, if success return ture

	bool isSame(questionNode* root1, questionNode* root2);//judge if 2 trees are the same

	bool isEqual(questionNode* root1, questionNode* root2);//judge if 2 trees are equal

	bool judgeTree();//judge if tree fit conditions

	vector<string> generateQue(int queNum);//generate questions

	void treeToStr(questionNode* root, string &pre);//transform tree to str

	vector<string> quesToStr(vector<questionNode*> Ques);//transform original questions to formal questions

public:
	questionCore(int Num = 6)
	{
		srand((unsigned int)(time(NULL)));

		quesNum = Num;
	}

	~questionCore()
	{
		int Num = questions.size();
		for (int i = 0; i < Num; i++)
		{
			questionNode* temp = questions[i];
			deleteQues(temp);
		}
	}

	bool Clear();//free and reset

	string Calc(string que);//get real fraction and return result

	vector<string> getQues();//get questions

	vector<string> getAns();//get answers

	bool setting(int queNum, int maxOpnum, int MinR, int MaxR, string op, bool fraction, int preci,string QPath,string APath);//setting

	void getResultFile();//getResultFile, output Questions.txt , Answers.txt
};
