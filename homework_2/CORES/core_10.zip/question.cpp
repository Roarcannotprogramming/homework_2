#include "question.h"
//random a~b
int questionCore::random(int a, int b)
{
	return (rand() % (b - a + 1)) + a;
}

//is operator
bool questionCore::isOp(char ch)
{
	auto it = find(ops.begin(), ops.end(), ch);
	if (it == ops.end())
		return false;
		return true;
}

//is num
bool questionCore::isNum(char ch)
{
	if (ch >= '0'&&ch <= '9')
		return true;
		return false;
}

//is decimal
bool questionCore::isDeci(string str)
{
	for (int i = 0; i < str.size(); i++)
	{
		if (str[i] == '.')
			return true;
	}
	return false;
}

//op's priority, higher means prior
int questionCore::priority(char op)
{
	switch (op)
	{
	case '#':return -2;
	case '\0':return -1;
	case '(':return 0;
	case ')':return 0;//avoid ( ) be put out
	case '+':
	case '-':return 1;
	case '*':
	case '%':
	case '|':
	case '/':return 2;
	case '^':return 3;
	default:return 4;
	}
}

// return (a op b)
double questionCore::CalcNum(double a, double b, char op)
{
	switch (op)
	{
	case '+':return (a + b);
	case '-':return (a - b);
	case '*':return (a * b);
	case '|':return a / b;
	case '/':return a / b;
	case '%':return (int)a % (int)b;
	case '^':return pow(a, b);
	default:return a;
	}
}

//return answer of que
double questionCore::CalcStr(string & que)
{//OPTR: ops' stack; OPEN: nums' stack
	int posTmp = que.find("*-");
	if (posTmp != -1)
		return 1;
	que.push_back('\0');
	stack<char> OPTR; OPTR.push('#');
	stack<double> OPEN;
	char ch = 'c', chTmp;
	double num1, num2;
	int pos = 0;



	while (ch != '\0' || OPTR.top() != '#')
	{
		if (ch != '\0') { ch = que[pos]; pos++; }
		if (!isOp(ch) && ch != '\0')
		{
			if (ch == ' ') continue;
			else numPush(OPEN, que, pos);
			continue;
		}
		switch (ch)
		{
		case '(':OPTR.push(ch); break;
		case ')':
			chTmp = OPTR.top();
			while (chTmp != '(')
			{
				if (OPEN.empty())
					throw "wrong form";
				num1 = OPEN.top(); OPEN.pop();
				if (OPEN.empty())
					throw "wrong form";
				num2 = OPEN.top(); OPEN.pop();
				OPEN.push(CalcNum(num2, num1, chTmp));
				OPTR.pop();
				chTmp = OPTR.top();
			}
			OPTR.pop();
			break;
		default:
			chTmp = OPTR.top();
			while (priority(chTmp) >= priority(ch))
			{
				OPTR.pop();
				if (OPEN.empty())
					throw "wrong form";
				num1 = OPEN.top(); OPEN.pop();
				if (OPEN.empty())
					throw "wrong form";
				num2 = OPEN.top(); OPEN.pop();
				OPEN.push(CalcNum(num2, num1, chTmp));
				chTmp = OPTR.top();
			}
			if (ch != '\0')OPTR.push(ch);
			break;
		}
	}
	return OPEN.top();
}

//push que's nums into stackT
void questionCore::numPush(stack<double> & stackT, string que, int & pos)
{
	string strT;
	char ch;
	while (!isOp(que[pos - 1]) && que[pos - 1] != '\0')
	{
		ch = que[pos - 1];
		strT.push_back(ch);
		pos++;
	}
	pos--;
	stackT.push(atof(strT.c_str()));
}

//find max divisor
int questionCore::getDivisor(string str)
{
	string numTmp;
	int times = 1;
	int divisorTmp = 1;
	int strLen = str.size();
	int backNum = 0;
	for (int i = 0; i < strLen; i++)
	{
		if (str[i] == '|'||str[i]=='/')
		{
			if (str[i + 1] == '(')
			{
				i++;

				while (i <= strLen)
				{
					if (str[i] == '(')backNum++;
					if (str[i] == ')')backNum--;
					if (str[i] == '|'||str[i]=='/')divisorTmp *= getDivisor(str.substr(i));
					if (divisorTmp == 0 || divisorTmp>maxRange || divisorTmp<0)
						return 1;

					numTmp.push_back(str[i]);
					if (backNum == 0)break;
					i++;
				}
			}
			else
			{
				while (isNum(str[i + 1]) && i + 1 <= strLen)
				{
					numTmp.push_back(str[i + 1]);
					i++;
				}

			}
			numTmp.insert(0, 1, '(');
			times *= int(CalcStr(numTmp.append(")*").append(to_string(int(divisorTmp)))));
			if (times == 0 || times>maxRange || times<0)
				return 1;
			numTmp.clear();
		}
	}
	if (times == 0 || times>maxRange || times<0)
		return 1;
	return times;
}

//Euclidean algorithm, zhanzhuanxiangchufa
int questionCore::gcd(int a, int b)
{
	if (b != 0)
		return gcd(b, a % b);
	else
		return a;
}

//judge if elems in question are positive 
bool questionCore::isPositive(questionNode* root, double &res)
{
	double res1 = 0, res2 = 0;
	bool flag1, flag2;
	if (root == NULL) return false;
	if (root->opsFlag == true)
	{
		flag1 = isPositive(root->lchild, res1);
		flag2 = isPositive(root->rchild, res2);
		res = CalcNum(res1, res2, char(root->value));
		if (res < 0 || res>maxRange)return false;
		else return flag1 && flag2;
	}
	else
	{
		res = root->value;
		return true;
	}
}

//generate tree from ques, if success return ture
bool questionCore::generateTree(vector<string> & ques)
{
	vector<string> res;

	string que, numStr;
	stack<char> OPTR; 
	stack<questionNode*> OPEN;
	questionNode *node1, *node2, *tempNode;


	for (int i = 0; i < ques.size(); i++)
	{
		que = ques[i];
		que.push_back('\0');
		OPTR.push('#');

		char ch = 'c', chTmp;
		int pos = 0;


		while (ch != '\0' || OPTR.top() != '#')
		{
			if (ch != '\0')ch = que[pos++];

			if (!isOp(ch) && ch != '\0')
			{
				if (ch == ' ') continue;
				else
				{
					while (!isOp(que[pos - 1]) && que[pos - 1] != '\0')
					{
						numStr.push_back(que[pos - 1]);
						pos++;
					}
					pos--;
					tempNode = new questionNode(atoi(numStr.c_str()), false);
					OPEN.push(tempNode);
					numStr.clear();
				}
				continue;
			}
			switch (ch)
			{
			case '(':OPTR.push(ch); break;
			case ')':
				chTmp = OPTR.top();
				while (chTmp != '(')
				{
					node1 = OPEN.top(); OPEN.pop();
					node2 = OPEN.top(); OPEN.pop();
					tempNode = new questionNode(int(chTmp), true, node2, node1);
					OPEN.push(tempNode);
					OPTR.pop();
					chTmp = OPTR.top();
				}
				OPTR.pop();
				break;
			default:
				chTmp = OPTR.top();
				while (priority(chTmp) >= priority(ch))
				{
					OPTR.pop();
					node1 = OPEN.top(); OPEN.pop();
					node2 = OPEN.top(); OPEN.pop();
					tempNode = new questionNode(int(chTmp), true, node2, node1);
					OPEN.push(tempNode);
					chTmp = OPTR.top();
				}
				if (ch != '\0')OPTR.push(ch);
				break;
			}//switch
		}//while
		questions.push_back(OPEN.top());
		OPEN.pop();
	}
	return true;
}

//judge if 2 trees are the same
bool questionCore::isSame(questionNode* root1, questionNode* root2)
{
	if (root1 == NULL && root2 == NULL)
		return true;
	else if (root1 == NULL || root2 == NULL)
		return false;

	if (root2->value != root1->value)
		return false;
	else
		return isSame(root1->rchild, root2->rchild) && isSame(root1->lchild, root2->lchild);
}

//judge if 2 trees are equal
bool questionCore::isEqual(questionNode* root1, questionNode* root2)
{
	if (root1 == NULL && root2 == NULL)
		return true;
	else if (root1 == NULL || root2 == NULL)
		return false;

	bool eFlag1, eFlag2;
	if (isSame(root1, root2))
		return true;
	else
	{
		eFlag1 = isEqual(root1->lchild, root2->lchild) && isEqual(root1->rchild, root2->rchild);
		eFlag2 = isEqual(root1->rchild, root2->lchild) && isEqual(root1->lchild, root2->rchild);
		return (eFlag1 || eFlag2) && (root1->value == root2->value);
	}
}

//judge if tree fit conditions
bool questionCore::judgeTree()
{
	int rquesNum = questions.size();

	for (int i = 0; i < rquesNum; i++)
	{
		fitFlag[i] = isPositive(questions[i], result[i]);
		for (int j = 0; j < i; j++)                   
		{
			if (result[i] == result[j])
			{
				if (isEqual(questions[i], questions[j]))
				{
					fitFlag[i] = false;
					isEqual(questions[i], questions[j]);
					break;
				}
			}
		}
	}
	return true;
}

//generate questions
vector<string> questionCore::generateQue(int queNum)
{
	vector<string> res;
	string strTmp;
	int num, chOp;
	string numStr;
	int leftParenPos, rightParenPos;
	int opNum, parenNum;
	bool isPow = false;
	int powFlag = 0;

	for (int i = 0; i < queNum; i++)
	{
		opNum = random(1, maxOpNum);

		for (int j = 0; j < opNum; j++)
		{
			if (isPow == false)
			{
				num = random(minRange, range);
				numStr = to_string(num);
			}
			else
			{
				num = random(2, 4);
				numStr = to_string(num);
				isPow = false;
			}
			chOp = ops[random(0, ops.size() - 3 - powFlag)];
			if (char(chOp) == '^')
			{
				isPow = true;
				powFlag = 1;
			}

			strTmp.append(numStr);
			strTmp.push_back(chOp);
		}
		num = random(minRange, range);
		numStr = to_string(num);
		strTmp.append(numStr);


		parenNum = random(0, opNum);

		for(;parenNum>0;parenNum--)
		{
			leftParenPos = random(0, strTmp.size() - 1);
			rightParenPos = random(leftParenPos + 1, strTmp.size());

			while ((leftParenPos != 0 && (!isNum(strTmp[leftParenPos]) || !isOp(strTmp[leftParenPos - 1])))||(leftParenPos != 0 && strTmp[leftParenPos]=='^'))
			{
				leftParenPos--;
			}
			strTmp.insert(leftParenPos, 1, '(');

			while (rightParenPos != strTmp.size() && (!isNum(strTmp[rightParenPos - 1]) || !isOp(strTmp[rightParenPos])))
			{
				rightParenPos++;
			}
			strTmp.insert(rightParenPos, 1, ')');
		}
		res.push_back(strTmp);
		strTmp.clear();
		powFlag = 0;
	}
	return res;
}

//transform tree to str
void questionCore::treeToStr(questionNode* root, string &pre)
{

	if (root == NULL) return ;
	if (root->opsFlag == false)
	{
		pre.append(to_string(root->value));
		return;
	}


	if (root->lchild->opsFlag == false)
		treeToStr(root->lchild, pre);
	else if ((priority(root->value) > priority(root->lchild->value))||(root->value=='^'))
	{
		pre.push_back('(');
		treeToStr(root->lchild, pre);
		pre.push_back(')');
	}
	else
		treeToStr(root->lchild, pre);

	pre.push_back(char(root->value));

	if (root->rchild->opsFlag == false)
		treeToStr(root->rchild, pre);
	else if ((priority(root->value) >= priority(root->rchild->value))||(root->value=='^'))
	{
		pre.push_back('(');
		treeToStr(root->rchild, pre);
		pre.push_back(')');
	}
	else
		treeToStr(root->rchild, pre);

	return;
}

//transform original questions to formal questions
vector<string> questionCore::quesToStr(vector<questionNode*> Quess)
{
	string strTmp;
	string strExm;
	vector<string> finishStr;
	int count = 0;
	int rightNum = 0;
	bool flag = true;
	int dot = 0;
	bool flag2 = true;

	for (int i = 0; i < Quess.size(); i++)
	{
		treeToStr(Quess[i], strTmp);
		for(int j=0;j<strTmp.size()-1;j++)
			if(strTmp[j] == '^')
				if((strTmp[j + 1] > '4') || (strTmp[j+1] == '('))
					{ flag = false; break; }
		if (!flag) {
			strTmp.clear();
			flag = true;
			continue;
		}
		strExm = Calc(strTmp);
		for (int j = 0; j < strExm.size(); j++) {
			if (strExm[j] == '\'') dot = j;
			if (strExm[j] == '|')
				if (j - dot > 3 || strExm.size() - j > 3)
					flag2 = false;
		}
		if (!flag2) {
			strTmp.clear();
			strExm.clear();
			flag2 = true;
			dot = 0;
			continue;
		}

		finishStr.push_back(strTmp);
		strTmp.clear();
		count++;
		if (count >= quesNum)
			break;
	}
	return finishStr;
}

//below:public function

//free and reset
bool questionCore::Clear() {
	int Num = questions.size();
	for (int i = 0; i < Num; i++)
	{
		questionNode* temp = questions[i];
		deleteQues(temp);
	}
	questions.clear();
	Answer.clear();
	return true;
}

//get real fraction and return result
string questionCore::Calc (string inQues)
{
	int devisor;
	int intNum;
	string tpQues;
	long res;

	if (fracFlag == true) {
		devisor = getDivisor(inQues);

		if (fracFlag&&devisor > 1 && devisor < maxRange && !isDeci(inQues))//get the real fraction
		{
			tpQues.append(to_string(devisor));
			tpQues.append("*(");
			tpQues.append(inQues).push_back(')');
			res = int(CalcStr(tpQues));
			intNum = gcd(res, devisor);
			tpQues = to_string(int(res / intNum));
			if (devisor / intNum != 1)
			{
				if (res > devisor)
				{
					tpQues.clear();
					tpQues.append(to_string(int(res / devisor))).append("'").append(to_string(int(res / intNum - int(res / devisor)*(devisor / intNum)))).append("|").append(to_string(devisor / intNum));
				}
				else
					tpQues.append("|").append(to_string(devisor / intNum));
			}
			return tpQues;
		}
		else
		{
			tpQues = to_string(CalcStr(inQues));
			for (int i = 0; i < 6 - precise; i++)
				tpQues.pop_back();
			if (precise == 0)
				tpQues.pop_back();
			return tpQues;
		}
	}
	//if not fraction
	else {
		tpQues = to_string(CalcStr(inQues));
		for (int i = 0; i < 6 - precise; i++)//set precise
			tpQues.pop_back();
		if (precise == 0)
			tpQues.pop_back();
		return tpQues;
	}
}

//get questions
vector<string> questionCore::getQues() {

	vector<string> originQues;
	vector<questionNode*> judgedQues;
	vector<string> finalQues, tempQues;

	originQues = generateQue(15 * quesNum);
	//generate 10 times questions and choose 1/10 from them
										  /*for (int i = 0; i < originQues.size()-1; i++) {
										  if (originQues[i].find("^("))
										  for (int j = i; j < originQues.size() - 2; j++)
										  originQues[j] = originQues[j + 1];
										  }*/
										  /*for (vector<string>::iterator it = originQues.begin();it != originQues.end();)
										  {
										  if ((*it).find("^("))
										  //ɾ��ָ��Ԫ�أ�����ָ��ɾ��Ԫ�ص���һ��Ԫ�ص�λ�õĵ�����
										  it = originQues.erase(it);
										  else
										  //������ָ����һ��Ԫ��λ��
										  ++it;
										  }*/

	generateTree(originQues);
	judgeTree();//build and judge

	for (int i = 0; i < questions.size(); i++)
	{
		if (fitFlag[i] == true)
			judgedQues.push_back(questions[i]);
	}


	finalQues = quesToStr(judgedQues);



	for (int i = 0; i < finalQues.size(); i++)
	{
		Answer.push_back(Calc(finalQues[i]));
	}

	//add ' ' between ops and nums
	string strTmp;
	for (int i = 0; i < finalQues.size(); i++)
	{
		strTmp = finalQues[i];
		for (int j = 0; j < strTmp.size(); j++)
		{
			if (strTmp[j] == '|'&&fracFlag == true)	continue;

			else if (isOp(strTmp[j]) && strTmp[j] != '('&&strTmp[j] != ')')
			{
				strTmp.insert(j, 1, ' ');
				strTmp.insert(j + 2, 1, ' ');
				j += 3;
			}
		}//for
		finalQues[i] = strTmp;
	}//for

	return finalQues;
}

//get answers
vector<string> questionCore::getAns() {
	return Answer;
}

//setting
bool questionCore::setting(int queNum=40, int maxOpnum=6, int MinR=0, int MaxR=15, string op="+-*/^", bool fraction=true, int preci=2,string QPath="Questions.txt",string APath="Answers.txt")
{
	quesNum = queNum;
	maxOpNum = maxOpnum;
	minRange = MinR;
	range = MaxR;
	ops.clear();
	for (int i = 0; i < op.size(); i++)
	{
		ops.push_back(op[i]);
	}
	fracFlag = fraction;
	precise = preci;
	QuePath = QPath;
	AnsPath = APath;
	setOps();
	return true;
}

//add ( ) into ops . if fraction, add function
void questionCore::setOps() {
	if (fracFlag)
		ops.insert(ops.end(), '|');
	ops.insert(ops.end(), 1,'(');
	ops.insert(ops.end(), 1,')');
}

//getResultFile, output Questions.txt , Answers.txt
void questionCore::getResultFile() {
	vector<string> Ques = getQues();
	vector<string> Ans = getAns();

	ofstream foutQues;
	foutQues.open(QuePath, ios::out);
	for (int i=0; i < Ques.size(); i++) {
		foutQues << Ques[i]<< endl;
	}
	foutQues.close();

	ofstream foutAns;
	foutAns.open(AnsPath, ios::out);
	for (int i = 0; i < Ans.size(); i++) {
		foutAns << Ans[i] << endl;
	}
	foutAns.close();
	Clear();
}





